Coloca aqui tu archivo de modelo en formato GGUF (extension .gguf).

La app funciona con cualquier modelo de instrucciones compatible con
llama.cpp. Recomendaciones para escritura creativa en ingles, corriendo en
una PC normal (sin GPU dedicada):

  - Meta-Llama-3.1-8B-Instruct (cuantizacion Q4_K_M, ~4.9 GB)
  - Mistral-7B-Instruct-v0.3 (cuantizacion Q4_K_M, ~4.4 GB)

Puedes buscar versiones .gguf ya cuantizadas de estos modelos en
Hugging Face (por ejemplo, en los repositorios de "bartowski" o
"lmstudio-community"). Busca el archivo terminado en "Q4_K_M.gguf" y
descargalo directamente en esta carpeta.

Requisitos aproximados de RAM: 8 GB libres para un modelo de 7-8B en Q4_K_M.
Si tu PC tiene menos RAM, busca una version mas chica (por ejemplo un modelo
de 3B) o una cuantizacion mas agresiva (Q4_K_S).

Nota: descargar el modelo requiere internet una sola vez. Una vez descargado,
la generacion de historias funciona completamente sin conexion.
